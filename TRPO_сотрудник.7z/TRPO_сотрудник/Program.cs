﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRPO_сотрудник
{
    class Program
    {
        static void Main(string[] args)
        { }
    public class Employee
        {
            private string lastName;
            private string firstName;
            private string middleName;
            private string position;

            public Employee(string lastName, string firstName, string middleName, string position)
            {
                this.lastName = lastName;
                this.firstName = firstName;
                this.middleName = middleName;
                this.position = position;
            }

            public string LastName
            {
                get { return lastName; }
                set { lastName = value; }
            }

            public string FirstName
            {
                get { return firstName; }
                set { firstName = value; }
            }

            public string MiddleName
            {
                get { return middleName; }
                set { middleName = value; }
            }

            public string Position
            {
                get { return position; }
                set { position = value; }
            }
        }
    }
}
